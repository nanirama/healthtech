import './src/styles/global.css'
import "./src/styles/styles.scss"