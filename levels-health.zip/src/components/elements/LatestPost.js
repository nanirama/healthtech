import * as React from "react"
import { useStaticQuery, graphql } from "gatsby"
import { GatsbyImage, getImage, StaticImage } from "gatsby-plugin-image"

import Authorimg from "../../assets/images/author.png"
import Signuplogo from "../../assets/images/favicon.png"


const LatestPost = () => {
    const { LastPost } = useStaticQuery(
        graphql`
          query {
            LastPost : allWpPost(sort: {order: DESC, fields: date}, limit: 1) {
                    edges {
                    node {
                        id
                        slug
                        title
                        guid
                        date
                        featuredImage {
                        node {
                            localFile {
                            childImageSharp {
                                gatsbyImageData(
                                    layout: FULL_WIDTH
                                    placeholder: BLURRED
                                    formats: [AUTO, WEBP, AVIF]
                                )
                            }
                            }
                        }
                        }
                    }
                    }
                }
          }
        `
    )
    const { title, featuredImage } = LastPost.edges[0].node
    return (
        <div className="max-w-7xl mx-auto px-4 md:mt-8 mt-4">
            <div className="grid lg:grid-cols-4 grid-cols-1 gap-8">
                <div className="flex flex-col">
                    <h6 className="text-xs uppercase cat_tlt pb-2">Category</h6>
                    <h2 className="xl:text-4xl lg:text-3xl text-2xl font-bold text-black pb-1">The ultimate guide to metabolic fitness</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad</p>
                    <div className="flex flex-col flex-end">
                        <div className="flex flex-row w-full items-center justify-between mt-10">
                            <div className="flex flex-row gap-4 items-center">
                                <img src={Authorimg} width={35} height={35} />
                                <p>Writer's name</p>
                            </div>
                            <p>Aug 12th, 2021</p>
                        </div>
                        <div className="flex flex-row w-full items-center justify-between mt-4">
                            <div className="flex flex-row gap-4 items-center">
                                <img src={Authorimg} width={35} height={35} />
                                <p>Reviewer's name</p>
                            </div>
                            <p>Aug 12th, 2021</p>
                        </div>
                    </div>
                </div>
                <div className="col-span-2 w-full flex md:justify-end justify-center">
                    <GatsbyImage image={getImage(featuredImage.node.localFile)} alt={title && title} width={600} height={539} className="rounded-xl w-full" />
                </div>

                <div className="bg-green-500 p-8 rounded ">
                    <div className="flex flex-row justify-between gap-10">
                        <h2 className="w-2/3 xl:text-4xl lg:text-3xl text-2xl text-white tracking-tight pb-1">Sign up for the Levels Newsletter</h2>
                        <img src={Signuplogo} width={40} height={50} />
                    </div>
                    <div className="border-y border-green-50 py-5 w-full mt-5">
                        <div className="w-full">
                            <input type="text" className="bg-white rounded-full text-left w-full py-3 text-center" placeholder="Type your email" />
                        </div>
                        <div className="w-full mt-4">
                            <button className="bg-green-400 rounded-full w-full py-3 text-center">Subscribe</button>
                        </div>
                    </div>
                </div>
            </div>


            {/* <div className="bg-black/[.03] border border-gray-200 rounded-l-xl md:rounded-b-none md:rounded-bl-xl rounded-b-xl flex md:flex-row flex-col-reverse justify-between items-center h-100">
                <div className="md:w-1/2 w-full xl:px-16 sm:px-10 px-4 md:py-5 py-14 flex flex-col lg:gap-6 gap-4 justify-center h-100">
                    <h6 className="text-xs uppercase cat_tlt">Nutrition</h6>
                    <h2 className="xl:text-6xl lg:text-5xl text-4xl text-black tracking-tight">{title && title}</h2>
                    <div className="w-100 flex flex-col">
                        <div className="w-100 text-sm font-bold">Braden McCarthy</div>
                        <div className="w-100 text-xs text-gray-400">11 min read</div>
                    </div>
                </div>
                <div className="md:w-1/2 w-full flex md:justify-end justify-center">
                    <GatsbyImage image={getImage(featuredImage.node.localFile)} alt={title && title} width={600} height={539} className="md:rounded-r-xl md:rounded-l-none rounded-t-xl w-full" />
                </div>
            </div> */}
        </div>
    )
}
export default LatestPost
